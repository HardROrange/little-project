#ifndef TOOLS_H
#define TOOLS_H

void anykey_continue(void);
void msg_show(const char* msg,float sec);
int menu(void);

#endif//TOOLS_H
