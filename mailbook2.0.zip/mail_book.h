#ifndef MAIL_BOOK_H
#define MAIL_BOOK_H

void add(void);
void del(void);
void mod(void);
void find(void);
void show(void);

#endif//MAIL_BOOK_H
