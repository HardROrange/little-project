/*
通讯录项目：
	姓名、性别、电话，最多存储50个联系人
	功能：
		1、添加新联系人	
		2、按名字删除联系人
		3、按名字修改联系人
		4、查找联系人，名字或电话，支持模糊查询
		5、显示所有联系人信息
		6、退出系统
*/
#include "mail_book.h" 
#include<getch.h>


int main(int argc,const char* argv[])
{

	for(;;)
	{
		puts("1、添加联系人");	
		puts("2、删除联系人");	
		puts("3、修改联系人");	
		puts("4、查找联系人");	
		puts("5、显示联系人");	
		puts("6、退出通讯录");	
		switch(getch())
		{
			case 49:	add();
			break;
			case 50:	del();
			break;
			case 51:	modify();
			break;
			case 52:	search();
			break;
			case 53:	show();
			break;
			case 54:	return 0;
		}
	}
}	
