#ifndef MAIL_BOOK_H
#define MAIL_BOOK_H
void add(void);
void del(void);
void modify(void);
void search(void);
void show(void);

#endif//MAIL_BOOK_H
