
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "mail_book.h"

static char name[50][20] = {};
static int cnt1=0;
static char tel[50][20] = {};
static char sex[50][5]={};


void add(void)
{
	puts("请输入要添加的联系人的名字:");
	gets(name[cnt1]);
	puts("请输入要添加的联系人的电话号码:");
	gets(tel[cnt1]);
	puts("请输入要添加的联系人的性别:");
	gets(sex[cnt1]); 
	system("clear");
	cnt1++;
}
void del(void)
{
	//char *p=NULL;
	puts("请输入要删除的联系人的名字:");
	char temp[20]={};
	gets(temp);
	for(int i =0;i<cnt1;i++)
	{
		if(strcmp(temp,name[i])==0)
		{
			for(int j=i;j<=cnt1;j++)
			{
				//*p=name[j+1];
				strcpy(name[j],name[j+1]);
				strcpy(tel[j],tel[j+1]);
				strcpy(sex[j],sex[j+1]);
				/*name[j]=name[j+1];
				tel[j]=tel[j+1];
				sex[j]=sex[j+1];*/
			}
			system("clear");
			puts("删除成功！");
			cnt1--;
			return;
		}
	}
	puts("查无此人");
}

void modify(void)
{
	char temp[20]={};
	puts("请输入要修改的联系人的名字:");
	gets(temp);
	for(int i =0;i<cnt1;i++)
	{
		if(strcmp(temp,name[i])==0)
		{
			printf("%s %s %s\n",name[i],tel[i],sex[i]) ;
			puts("将名字修改为：");
			gets(name[i]); 
			puts("将电话修改为：");
			gets(tel[i]);
			puts("将性别修改为：");
			gets(sex[i]);
			system("clear");
			puts("修改成功！");
		}
		else
		{
			system("clear");
			puts("查无此人"); 
		}
	}
}

void search(void)
{
	char *p1=NULL;
	char *p2=NULL;
	char *p3=NULL;
	char strin[50]={};
	puts("请输入要查找的内容：");
	gets(strin);
	for(int i =0;i<cnt1;i++)
	{
		p1=strstr(name[i],strin);
		p2=strstr(tel[i],strin);
		p3=strstr(sex[i],strin);
		if(p1!=NULL||p2!=NULL||p3!=NULL)
		{
			printf("%s %s %s\n",name[i],tel[i],sex[i]) ;
		}
	}	
}

void show(void)
{
	system("clear");
	for(int i =0;i<cnt1;i++)
	{
		printf("%s %s %s\n",name[i],tel[i],sex[i]);
	}	
}
